/*******************************************************************************
* File Name: Joystick_X.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Joystick_X_H) /* Pins Joystick_X_H */
#define CY_PINS_Joystick_X_H

#include "cytypes.h"
#include "cyfitter.h"
#include "Joystick_X_aliases.h"


/***************************************
*     Data Struct Definitions
***************************************/

/**
* \addtogroup group_structures
* @{
*/
    
/* Structure for sleep mode support */
typedef struct
{
    uint32 pcState; /**< State of the port control register */
    uint32 sioState; /**< State of the SIO configuration */
    uint32 usbState; /**< State of the USBIO regulator */
} Joystick_X_BACKUP_STRUCT;

/** @} structures */


/***************************************
*        Function Prototypes             
***************************************/
/**
* \addtogroup group_general
* @{
*/
uint8   Joystick_X_Read(void);
void    Joystick_X_Write(uint8 value);
uint8   Joystick_X_ReadDataReg(void);
#if defined(Joystick_X__PC) || (CY_PSOC4_4200L) 
    void    Joystick_X_SetDriveMode(uint8 mode);
#endif
void    Joystick_X_SetInterruptMode(uint16 position, uint16 mode);
uint8   Joystick_X_ClearInterrupt(void);
/** @} general */

/**
* \addtogroup group_power
* @{
*/
void Joystick_X_Sleep(void); 
void Joystick_X_Wakeup(void);
/** @} power */


/***************************************
*           API Constants        
***************************************/
#if defined(Joystick_X__PC) || (CY_PSOC4_4200L) 
    /* Drive Modes */
    #define Joystick_X_DRIVE_MODE_BITS        (3)
    #define Joystick_X_DRIVE_MODE_IND_MASK    (0xFFFFFFFFu >> (32 - Joystick_X_DRIVE_MODE_BITS))

    /**
    * \addtogroup group_constants
    * @{
    */
        /** \addtogroup driveMode Drive mode constants
         * \brief Constants to be passed as "mode" parameter in the Joystick_X_SetDriveMode() function.
         *  @{
         */
        #define Joystick_X_DM_ALG_HIZ         (0x00u) /**< \brief High Impedance Analog   */
        #define Joystick_X_DM_DIG_HIZ         (0x01u) /**< \brief High Impedance Digital  */
        #define Joystick_X_DM_RES_UP          (0x02u) /**< \brief Resistive Pull Up       */
        #define Joystick_X_DM_RES_DWN         (0x03u) /**< \brief Resistive Pull Down     */
        #define Joystick_X_DM_OD_LO           (0x04u) /**< \brief Open Drain, Drives Low  */
        #define Joystick_X_DM_OD_HI           (0x05u) /**< \brief Open Drain, Drives High */
        #define Joystick_X_DM_STRONG          (0x06u) /**< \brief Strong Drive            */
        #define Joystick_X_DM_RES_UPDWN       (0x07u) /**< \brief Resistive Pull Up/Down  */
        /** @} driveMode */
    /** @} group_constants */
#endif

/* Digital Port Constants */
#define Joystick_X_MASK               Joystick_X__MASK
#define Joystick_X_SHIFT              Joystick_X__SHIFT
#define Joystick_X_WIDTH              1u

/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in Joystick_X_SetInterruptMode() function.
     *  @{
     */
        #define Joystick_X_INTR_NONE      ((uint16)(0x0000u)) /**< \brief Disabled             */
        #define Joystick_X_INTR_RISING    ((uint16)(0x5555u)) /**< \brief Rising edge trigger  */
        #define Joystick_X_INTR_FALLING   ((uint16)(0xaaaau)) /**< \brief Falling edge trigger */
        #define Joystick_X_INTR_BOTH      ((uint16)(0xffffu)) /**< \brief Both edge trigger    */
    /** @} intrMode */
/** @} group_constants */

/* SIO LPM definition */
#if defined(Joystick_X__SIO)
    #define Joystick_X_SIO_LPM_MASK       (0x03u)
#endif

/* USBIO definitions */
#if !defined(Joystick_X__PC) && (CY_PSOC4_4200L)
    #define Joystick_X_USBIO_ENABLE               ((uint32)0x80000000u)
    #define Joystick_X_USBIO_DISABLE              ((uint32)(~Joystick_X_USBIO_ENABLE))
    #define Joystick_X_USBIO_SUSPEND_SHIFT        CYFLD_USBDEVv2_USB_SUSPEND__OFFSET
    #define Joystick_X_USBIO_SUSPEND_DEL_SHIFT    CYFLD_USBDEVv2_USB_SUSPEND_DEL__OFFSET
    #define Joystick_X_USBIO_ENTER_SLEEP          ((uint32)((1u << Joystick_X_USBIO_SUSPEND_SHIFT) \
                                                        | (1u << Joystick_X_USBIO_SUSPEND_DEL_SHIFT)))
    #define Joystick_X_USBIO_EXIT_SLEEP_PH1       ((uint32)~((uint32)(1u << Joystick_X_USBIO_SUSPEND_SHIFT)))
    #define Joystick_X_USBIO_EXIT_SLEEP_PH2       ((uint32)~((uint32)(1u << Joystick_X_USBIO_SUSPEND_DEL_SHIFT)))
    #define Joystick_X_USBIO_CR1_OFF              ((uint32)0xfffffffeu)
#endif


/***************************************
*             Registers        
***************************************/
/* Main Port Registers */
#if defined(Joystick_X__PC)
    /* Port Configuration */
    #define Joystick_X_PC                 (* (reg32 *) Joystick_X__PC)
#endif
/* Pin State */
#define Joystick_X_PS                     (* (reg32 *) Joystick_X__PS)
/* Data Register */
#define Joystick_X_DR                     (* (reg32 *) Joystick_X__DR)
/* Input Buffer Disable Override */
#define Joystick_X_INP_DIS                (* (reg32 *) Joystick_X__PC2)

/* Interrupt configuration Registers */
#define Joystick_X_INTCFG                 (* (reg32 *) Joystick_X__INTCFG)
#define Joystick_X_INTSTAT                (* (reg32 *) Joystick_X__INTSTAT)

/* "Interrupt cause" register for Combined Port Interrupt (AllPortInt) in GSRef component */
#if defined (CYREG_GPIO_INTR_CAUSE)
    #define Joystick_X_INTR_CAUSE         (* (reg32 *) CYREG_GPIO_INTR_CAUSE)
#endif

/* SIO register */
#if defined(Joystick_X__SIO)
    #define Joystick_X_SIO_REG            (* (reg32 *) Joystick_X__SIO)
#endif /* (Joystick_X__SIO_CFG) */

/* USBIO registers */
#if !defined(Joystick_X__PC) && (CY_PSOC4_4200L)
    #define Joystick_X_USB_POWER_REG       (* (reg32 *) CYREG_USBDEVv2_USB_POWER_CTRL)
    #define Joystick_X_CR1_REG             (* (reg32 *) CYREG_USBDEVv2_CR1)
    #define Joystick_X_USBIO_CTRL_REG      (* (reg32 *) CYREG_USBDEVv2_USB_USBIO_CTRL)
#endif    
    
    
/***************************************
* The following code is DEPRECATED and 
* must not be used in new designs.
***************************************/
/**
* \addtogroup group_deprecated
* @{
*/
#define Joystick_X_DRIVE_MODE_SHIFT       (0x00u)
#define Joystick_X_DRIVE_MODE_MASK        (0x07u << Joystick_X_DRIVE_MODE_SHIFT)
/** @} deprecated */

#endif /* End Pins Joystick_X_H */


/* [] END OF FILE */
